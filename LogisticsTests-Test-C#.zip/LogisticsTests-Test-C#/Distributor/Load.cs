﻿public class Load
{
    // Armazena o peso, volume e prioridade da carga
    public double Weight { get; set; }
    public double Volume { get; set; }
    public Priority Priority { get; set; }

    // Construtor que inicializa os atributos da carga
    public Load(double weight, double volume, Priority priority)
    {
        Weight = weight;
        Volume = volume;
        Priority = priority;
    }
}

// Definição de prioridade das cargas
public enum Priority
{
    Normal,
    High
}