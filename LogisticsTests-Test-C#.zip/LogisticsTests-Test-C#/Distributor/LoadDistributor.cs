﻿public class LoadDistributor
{
    // Método para calcular o peso e volume total das cargas e verificar se os valores são validos
    public (double TotalWeight, double TotalVolume) CalculateTotalLoad(List<Load> loads)
    {
        if (loads.Any(load => load.Weight < 0 || load.Volume < 0))
        {
            throw new ArgumentException("Peso e volume não podem ser negativos.");
        }

        double totalWeight = loads.Sum(load => load.Weight);
        double totalVolume = loads.Sum(load => load.Volume);

        return (totalWeight, totalVolume);
    }

    // Método para distribuir as cargas entre os caminhões e atualizar as cargas que não puderam ser alocadas
    public (List<Truck> trucks, List<Load> unallocatedLoads) DistributeLoads(List<Truck> trucks, List<Load> loads)
    {
        var orderedLoads = loads.OrderByDescending(load => load.Priority).ToList();
        var unallocatedLoads = new List<Load>();

        foreach (var load in orderedLoads)
        {
            bool allocated = false;

            // Ordena os caminhões por quantidade de cargas, peso máximo e volume máximo
            var sortedTrucks = trucks.OrderBy(truck => truck.Loads.Count).ThenByDescending(truck => truck.MaxWeight).ThenByDescending(truck => truck.MaxVolume).ToList();

            // Procura o caminhão mais adequado para a carga atual, caso não tenha, volta a lista de cargas não alocadas
            foreach (var truck in sortedTrucks)
            {
                if (truck.CanLoad(load))
                {
                    truck.LoadCargo(load);
                    allocated = true;
                    break;
                }
            }
            if (!allocated)
            {
                unallocatedLoads.Add(load);
            }
        }
        // Retorna lista atualizada
        return (trucks, unallocatedLoads);
    }
}