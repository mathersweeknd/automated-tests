﻿public class Truck
{
    // Listas para armazenar as cargas baseadas no peso e volume
    public double MaxWeight { get; set; }
    public double MaxVolume { get; set; }
    public List<Load> Loads { get; set; } = new List<Load>();

    // Adicionar carga ao caminhão
    public bool CanLoad(Load load)
    {
        return MaxWeight >= load.Weight && MaxVolume >= load.Volume;
    }

    // Método para carregar o caminhão se a capacidade permitir e atualiza a capacidade atual do caminhão
    public void LoadCargo(Load load)
    {
        if (CanLoad(load))
        {
            Loads.Add(load);
            MaxWeight -= load.Weight;
            MaxVolume -= load.Volume;
        }
        else
        {
            throw new InvalidOperationException("O caminhão não pode carregar essa carga devido à capacidade.");
        }
    }
}